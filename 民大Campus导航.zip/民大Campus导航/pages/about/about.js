const CLOUD_PREFIX = "cloud://cloud1-4gh72aev1c85874d.636c-cloud1-4gh72aev1c85874d-1360566409";

Page({
  data: {
    swiperImages: [
      `${CLOUD_PREFIX}/img/hall.jpg`,
      `${CLOUD_PREFIX}/img/lib.jpg`,
      `${CLOUD_PREFIX}/img/longhall.jpg`,
      `${CLOUD_PREFIX}/img/sunset.jpg`
    ],
  }
});