Page({
  data: {}
});