Page({
  data: {},
  toPage6() {
    wx.navigateTo({ url: '/pages/page6/page6' });
  }
});